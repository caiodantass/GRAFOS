from bibgrafo.grafo_lista_adjacencia import GrafoListaAdjacencia
from bibgrafo.grafo_exceptions import *
from bibgrafo.grafo_errors import *


class MeuGrafo(GrafoListaAdjacencia):

    def vertices_nao_adjacentes(self):
        '''
        Provê uma lista de vértices não adjacentes no grafo. A lista terá o seguinte formato: [X-Z, X-W, ...]
        Onde X, Z e W são vértices no grafo que não tem uma aresta entre eles.
        :return: Uma lista com os pares de vértices não adjacentes
        '''

        arestasGrafos = set()
        for a in self.arestas:
            arestaAtual = self.arestas[a]
            verticesArestas = f'{arestaAtual.v1}-{arestaAtual.v2}'
            arestasGrafos.add(verticesArestas)


        verticesNaoAdj = set()
        for i in range(len(self.vertices)):
            for j in range(i + 1, len(self.vertices)):
                novaAresta = f'{self.vertices[i]}-{self.vertices[j]}'
                if novaAresta not in arestasGrafos and novaAresta[::-1] not in arestasGrafos:
                    verticesNaoAdj.add(novaAresta)

        return verticesNaoAdj

    def ha_laco(self):
        '''
        Verifica se existe algum laço no grafo.
        :return: Um valor booleano que indica se existe algum laço.
        '''

        for aresta in self._arestas:
            if self._arestas[aresta].v1 == self._arestas[aresta].v2:
                return True
        return False

    def grau(self, V=''):
        '''
        Provê o grau do vértice passado como parâmetro
        :param V: O rótulo do vértice a ser analisado
        :return: Um valor inteiro que indica o grau do vértice
        :raises: VerticeInvalidoException se o vértice não existe no grafo
        '''

        if not self.existe_rotulo_vertice(V):
            raise VerticeInvalidoError

        g = 0
        for a in self.arestas:
            if self._arestas[a].v1.rotulo == V:
                g += 1
            if self._arestas[a].v2.rotulo == V:
                g += 1
        return g

    def ha_paralelas(self):
        '''
        Verifica se há arestas paralelas no grafo
        :return: Um valor booleano que indica se existem arestas paralelas no grafo.
        '''

        arestas = set()
        for a in self.arestas:
            arestaAtual = self.arestas[a]
            verticesAresta = (arestaAtual.v1.rotulo, arestaAtual.v2.rotulo)

            if verticesAresta in arestas or verticesAresta[::-1] in arestas:
                return True
            arestas.add(verticesAresta)

        return False

    def arestas_sobre_vertice(self, V):
        '''
        Provê uma lista que contém os rótulos das arestas que incidem sobre o vértice passado como parâmetro
        :param V: O vértice a ser analisado
        :return: Uma lista os rótulos das arestas que incidem sobre o vértice
        :raises: VerticeInvalidoException se o vértice não existe no grafo
        '''

        if not self.existe_rotulo_vertice(V):
            raise VerticeInvalidoError

        aux = set()
        for a in self.arestas:
            if self.arestas[a].v1.rotulo == V or self.arestas[a].v2.rotulo == V:
                aux.add(a)

        return aux

    def eh_completo(self):
        '''
        Verifica se o grafo é completo.
        :return: Um valor booleano que indica se o grafo é completo
        '''

        for c in self.vertices:
            if self.grau(c.rotulo) != (len(self.vertices) - 1):
                return False
        return True

    def dijkstra_drone(self, vi, vf, carga:int, carga_max:int, pontos_recarga:list()):
        pass


    def dfs(self, V=' '):

          arvore_dfs = MeuGrafo()
          arvore_dfs.adiciona_vertice(V)
          return self.dfs_aux(V, arvore_dfs)

    def dfs_aux(self, V, arvore_dfs):

          if len(self.vertices) == len(arvore_dfs.vertices):
              return arvore_dfs
          if not self.existe_rotulo_vertice(V):
              raise VerticeInvalidoError

          rotulo = self.arestas_sobre_vertice(V)
          rotulos = list(rotulo)
          rotulos.sort()
          for a in rotulos:
              if not arvore_dfs.existe_rotulo_vertice(a):
                  if V == self.arestas[a].v1.rotulo:
                      r = self.arestas[a].v2.rotulo
                  else:
                      r = self.arestas[a].v1.rotulo

                  if not arvore_dfs.existe_rotulo_vertice(r):
                      arvore_dfs.adiciona_vertice(r)
                      arvore_dfs.adiciona_aresta(self.arestas[a])
                      self.dfs_aux(r, arvore_dfs)

          return arvore_dfs


    def bfs(self, V=''):
         if not self.existe_rotulo_vertice(V):
             raise VerticeInvalidoError

         arvore_bfs = MeuGrafo()
         arvore_bfs.adiciona_vertice(V)

         return  self.bfs_aux(arvore_bfs, V)

    def vertice_oposto(self, aresta, vertice=''):
         if aresta.v1.rotulo == vertice:
             return aresta.v2.rotulo
         elif aresta.v2.rotulo == vertice:
             return aresta.v1.rotulo
         else:
             raise VerticeInvalidoError

    def bfs_aux(self, arvore_bfs, V=''):
         arestas_novas = []
         arestas_incidentes = list(self.arestas_sobre_vertice(V))
         arestas_incidentes.sort()

         for aresta in arestas_incidentes:
             if self.arestas[aresta] in arvore_bfs.arestas.values():
                 continue
             oposto = self.vertice_oposto(self.arestas[aresta], V)
             if arvore_bfs.existe_rotulo_vertice(oposto):
                 continue
             oposto = self.vertice_oposto(self.arestas[aresta], V)
             if arvore_bfs.existe_rotulo_vertice(oposto):
                 continue

             arvore_bfs.adiciona_vertice(oposto)
             arvore_bfs.adiciona_aresta(self.arestas[aresta])
             arestas_novas.append(aresta)

         for aresta in arestas_novas:
             oposto = self.vertice_oposto(self.arestas[aresta], V)
             arvore_bfs = self.bfs_aux(arvore_bfs, oposto)

         return arvore_bfs


    def caminho(self, n):
        maior_caminho = []
        for vertice in self.vertices:
            caminho = self.maior_caminho(vertice.rotulo)
            if len(caminho) > len(maior_caminho):
                maior_caminho = caminho
        # quantidade de arestas
        comp_maior_caminho = (len(maior_caminho) - 1) / 2
        if n > comp_maior_caminho:
            return False
        return maior_caminho[:(n*2) + 1]

    def maior_caminho(self, vertice):
        if not self.existe_rotulo_vertice(vertice):
            raise VerticeInvalidoError
        caminho = []
        caminho.append(vertice)
        return self.maior_caminho_aux(vertice, caminho)

    def maior_caminho_aux(self, vertice, caminho):
        caminhos_novos = []
        arestas_incidentes = list(self.arestas_sobre_vertice(vertice))
        arestas_incidentes.sort()
        for rot_aresta in arestas_incidentes:
            if rot_aresta in caminho:
                continue
            oposto = self.proximo_vertice(self.arestas[rot_aresta], vertice)
            if oposto in caminho:
                continue
            novo = caminho[:]
            novo.append(rot_aresta)
            novo.append(oposto)
            novo = self.maior_caminho_aux(oposto, novo)
            caminhos_novos.append(novo)
        if len(caminhos_novos) == 0:
            return caminho
        maior = caminhos_novos[0]
        for c in caminhos_novos:
            if len(c) > len(maior):
                maior = c
        return maior

    def proximo_vertice(self, aresta, vertice=""):
        if aresta.v1.rotulo == vertice:
            return aresta.v2.rotulo
        elif aresta.v2.rotulo == vertice:
            return aresta.v1.rotulo
        else:
            raise VerticeInvalidoError


    def conexo(self):

        if len(self.vertices) == 0:

            return False

        dfs = self.dfs(self.vertices[0].rotulo)
        return len(self.vertices) == len(dfs.vertices)


    def ha_ciclo(self, raiz='', visitados=None, ciclo=None, arestas=None):

        if ((visitados is None) and (ciclo is None) and (arestas is None) and (raiz == '')):
            vertices = sorted(self.N)
            raiz = vertices[0]
            visitados = ciclo = arestas = []
            arestas = sorted(self.A.values())
            arestas = list(arestas)

        visitados.append(raiz)
        if ((len(visitados) > 1) and (visitados[0] == visitados[-1])):
            return ciclo

        for aresta in arestas:
            if (aresta[0] == raiz):
                for aux in self.A:
                    if (self.A[aux] == aresta):
                        ciclo.append(aux)
                        break

                arestaAux = aresta[2]
                arestas.remove(aresta)
                return self.ha_ciclo(arestaAux, visitados, ciclo, arestas)

            elif (aresta[2] == raiz):
                for aux in self.A:
                    if (self.A[aux] == aresta):
                        ciclo.append(aux)
                        break
                arestaAux = aresta[0]
                arestas.remove(aresta)
                return self.ha_ciclo(arestaAux, visitados, ciclo, arestas)

        for i in range(len(ciclo)):
            if (len(ciclo) > 1):
                if (ciclo[0] == ciclo[-1]):
                    return ciclo
                else:
                    ciclo.remove(ciclo[0])
            else:
                break
        return False