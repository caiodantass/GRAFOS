from bibgrafo.grafo_lista_adjacencia import GrafoListaAdjacencia
from bibgrafo.grafo_exceptions import *
from bibgrafo.grafo_errors import *


class MeuGrafo(GrafoListaAdjacencia):

    def vertices_nao_adjacentes(self):
        '''
        Provê uma lista de vértices não adjacentes no grafo. A lista terá o seguinte formato: [X-Z, X-W, ...]
        Onde X, Z e W são vértices no grafo que não tem uma aresta entre eles.
        :return: Uma lista com os pares de vértices não adjacentes
        '''

        arestasGrafos = set()
        for a in self.arestas:
            arestaAtual = self.arestas[a]
            verticesArestas = f'{arestaAtual.v1}-{arestaAtual.v2}'
            arestasGrafos.add(verticesArestas)


        verticesNaoAdj = set()
        for i in range(len(self.vertices)):
            for j in range(i + 1, len(self.vertices)):
                novaAresta = f'{self.vertices[i]}-{self.vertices[j]}'
                if novaAresta not in arestasGrafos and novaAresta[::-1] not in arestasGrafos:
                    verticesNaoAdj.add(novaAresta)

        return verticesNaoAdj

    def ha_laco(self):
        '''
        Verifica se existe algum laço no grafo.
        :return: Um valor booleano que indica se existe algum laço.
        '''

        for aresta in self._arestas:
            if self._arestas[aresta].v1 == self._arestas[aresta].v2:
                return True
        return False

    def grau(self, V=''):
        '''
        Provê o grau do vértice passado como parâmetro
        :param V: O rótulo do vértice a ser analisado
        :return: Um valor inteiro que indica o grau do vértice
        :raises: VerticeInvalidoException se o vértice não existe no grafo
        '''

        if not self.existe_rotulo_vertice(V):
            raise VerticeInvalidoError

        g = 0
        for a in self.arestas:
            if self._arestas[a].v1.rotulo == V:
                g += 1
            if self._arestas[a].v2.rotulo == V:
                g += 1
        return g

    def ha_paralelas(self):
        '''
        Verifica se há arestas paralelas no grafo
        :return: Um valor booleano que indica se existem arestas paralelas no grafo.
        '''

        arestas = set()
        for a in self.arestas:
            arestaAtual = self.arestas[a]
            verticesAresta = (arestaAtual.v1.rotulo, arestaAtual.v2.rotulo)

            if verticesAresta in arestas or verticesAresta[::-1] in arestas:
                return True
            arestas.add(verticesAresta)

        return False

    def arestas_sobre_vertice(self, V):
        '''
        Provê uma lista que contém os rótulos das arestas que incidem sobre o vértice passado como parâmetro
        :param V: O vértice a ser analisado
        :return: Uma lista os rótulos das arestas que incidem sobre o vértice
        :raises: VerticeInvalidoException se o vértice não existe no grafo
        '''

        if not self.existe_rotulo_vertice(V):
            raise VerticeInvalidoError

        aux = set()
        for a in self.arestas:
            if self.arestas[a].v1.rotulo == V or self.arestas[a].v2.rotulo == V:
                aux.add(a)

        return aux

    def eh_completo(self):
        '''
        Verifica se o grafo é completo.
        :return: Um valor booleano que indica se o grafo é completo
        '''

        for c in self.vertices:
            if self.grau(c.rotulo) != (len(self.vertices) - 1):
                return False
        return True

    def dijkstra_drone(self, vi, vf, carga:int, carga_max:int, pontos_recarga:list()):
        pass